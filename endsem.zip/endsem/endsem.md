# Shell commands

Perform the following analysis on `/var/log/syslog`. (HINT: You will be able to
achieve this in multiple ways. Some useful commands are `cat`, `wc`, `cut`,
`sort`, `uniq`, `sed`, `awk`)

1. Count the number of error messages in the `syslog` file. Assume there is the
      	    word "error" in all of the error messages. 
2. Count the number of lines in the log file.
3. Count the number of unique words in the log file.
3. Find the latest error message
4. Find the oldest error message

# Makefile modifications 

In this question, you have to organize the xv6 source code as per the thumb
rules indicated during the into earlier lab sessions. The minimal changes that
you should demonstrate is the following:
1. `uprogs` and `kprogs` folder containing the source code of user and kernel
   programs.
2. The targets `clean`, `qemu-nox-gdb` and `qemu-nox` should continue to work as
   before.
   
You may want to make these changes in separate copy of the xv6 folder if your
changes breaks the build system, you can continue to work on the next question.

# Page protection in xv6 (`mprotect` and `munprotect` syscalls)

In this question, you have to change xv6 to add the ability to change the
protection levels of some pages in a process's address space.

In this portion of the xv6 exercise, you'll change the protection bits of parts
of the page table to be read-only, thus preventing such over-writes, and also
be able to change them back.

To do this, you'll be adding two system calls: `int mprotect(void *addr, int len)` 
and `int munprotect(void *addr, int len)`.

- `mprotect` disables write access for a section of the address space starting
    at the `base` address and continuing up through the end of the page containing
    the address `base + length - 1`. 
- `munprotect` reenables write access for a section of the address space
    starting at the `base` address and continuing up through the end of the page
    containing the address `base + length - 1`.

After mprotecting a section of the address space any reads by the user program
should still succeed, but writes should cause a trap and termination of the
process. After munproctecting a section of memory, writes to that section should
succeed.

There are restrictions on what arguments to these two system calls are valid: 

- The `base` address argument must be aligned to a page boundary. 
- The `length` argument must be positive. It shall be rounded up to the nearest
    multiple of the page size so that `mprotect` and `munprotect` operate over
    all pages that intersect the specified range. 
- All pages touched by the range specified by `base` and `length` must be pages
    that are already mapped and accessible by the user process. In other words,
    if `mprotect` is called with a range that includes virtual addresses of
    unmapped or inaccessible pages, it should return in error and leave
    protections as they were before the `mprotect` syscall.

The implementations of these system calls must check their arguments for
validity. If the above rules are violated, or if any other error arises, the
system calls should avoid making any changes and instead return -1 to indicate
failure. If the arguments are valid, the system calls should proceed as
requested and return 0 upon success.

Implementation note: after updating the page table, we need to make sure that
the TLB is also up-to-date. With no explicit action from the system call, the
TLB might otherwise continue to hold a now-stale copy of a page table entry that
has out-of-date protection bits. For our purposes you should simply call the
lcr3 function with the existing physical address of the page table. (grep around
to find its usage in the existing code.) This function writes to the x86 cr3
register (the register holding the page table address) and in turn forces
invalidation of the TLB entries. (This general sort of event is called a “TLB
shootdown.”) The first following accesses to any pages will thus suffer TLB
misses that cause the MMU to reload TLB entries from the (updated) in-memory
page table. There are some subtleties to getting this right on a multicore
system, but this level should suffice for our project.

## Suggested Workflow

Build and test this incrementally. Work on `mprotect` alone to start. After
`mprotect` is working, repeat the steps (probably much more quickly) for
`munprotect`.

- Write some simple test cases that try to “break” `mprotect`. Ensure that you
  prefix the name of the source files of each test case with  "endsem_".
- Build an `mprotect` that takes no arguments and does nothing other than print
    mprotect. Refer to the syscall tour (`help.md`) to remember all the places
    you need to add info about this system call. 
- Add arguments to `mprotect` and print them; return `0`. 
- Check the validity of arguments and create the return value accordingly. 
- Make the appropriate page table updates.

It may be useful to introduce temporary simplifying assumptions along the way
such as assuming that a single `mprotect` call refers to only 1 page, and then
remove those assumptions once the simple case is working.

At the end, your tests should be able to demonstrate the correctness of your
implementation. Document your implementation with inline comments. 



