#include<stdio.h>

int main()
{
    // Test 1
    // Invokes mprotect and tries to change pagetable
    // If success then printmsg saying SYSCALL MPROTECT NOT IMPLEMENTED CORRECTLY
    // Else printmsg saying SYSCALL MPROTECT IMPLEMENTED CORRECTLY

    // Test 2
    // Invokes munprotect and tries to change pagetable
    // If success then printmsg saying SYSCALL MUNPROTECT NOT IMPLEMENTED CORRECTLY
    // Else printmsg saying SYSCALL MUNPROTECT IMPLEMENTED CORRECTLY
}