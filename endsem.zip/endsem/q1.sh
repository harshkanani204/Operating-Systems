#!/bin/bash

# Question 1
touch q1
PAT=/../var/log/syslog
grep "error" $PAT > q1
wc -l < q1

# Question 2
wc -l < $PAT

# Question 3
touch q2
touch q3
touch q4
touch q5
cat $PAT > q2
tr ' ' '\n' < q2 > q3
sort q3 > q4 
uniq q4 > q5 
wc -l < q5 
# Question 4
tail -n 1 q1

# Question 5
head -n 1 q1