# Question 1
File `q1.sh` contains the script there are some junkfiles also for better illustration one can remove it using `rm`.
```bash
#!/bin/bash

# Question 1: Count the number of error messages in the syslog file. Assume there is the word “error” in all of the error messages.
touch q1
PAT=/../var/log/syslog
grep "error" $PAT > q1
wc -l < q1

# Question 2: Count the number of lines in the log file.
wc -l < $PAT

# Question 3: Count the number of unique words in the log file.
touch q2
touch q3
touch q4
touch q5
cat $PAT > q2
tr ' ' '\n' < q2 > q3
sort q3 > q4 
uniq q4 > q5 
wc -l < q5 

# Question 4: Find the latest error message
tail -n 1 q1

# Question 5: Find the oldest error message
head -n 1 q1

```

# Question 2
Change Make-file in the following way:
- add rules which will segregate uprogs and kprogs from each other and send them into the folders `UPROGS` and `KPROGS` respectively.
- some minor changes in path for correct execution of `make clean`, `make qemu-nox`, `make qemu-nox-gdb` 

# Question 3

### **Files to Change in order to implement 2 SYSCALLS:**
- **syscall.c**
    ```c
    extern int sys_mprotect(void);
    extern int sys_munprotect(void);

    [SYS_mprotect] sys_mprotect,
    [SYS_munprotect] sys_munprotect,
    ```
- **syscall.h**

    ```c
    #define SYS_mprotect 22
    #define SYS_munprotect 23
    ```
- **sysproc.c**
    ```c
    int
    mprotect(void *addr, int len)
    {
    //  Implement mprotect
    }

    int
    munprotect(void *addr, int len)
    {
    //  Implement mprotect
    }
    ```
- **usys.S**
    ```c
    SYSCALL(mprotect)
    SYSCALL(munprotect) 
    ```
- **user.h**
    ```c
    int mprotect(void *addr, int len); 
    int munprotect(void *addr, int len);
    ```
- and some minor changes in other files to make xv6 support these system calls


### **Implementation Part:**

1) After changing all the files mentioned above we'll need to implement the syscall in sysproc.c where it changes the protection bits of part of the page table.
2) In the `mprotect` we'll change the protection bit to read-only of the appropriate pagetable.
3) In the `munprotect` we'll change the protection bit to write of the appropriate pagetable.

## Pseudo code for `mprotect` and `munprotect`

```c
int mprotect(void *addr, int len)
{
    //  Implement mprotect
    if(len<=0)  return -1;

    findallPages(void *addr, int len) // Function which will return all the pages that intersect the specified range

    changeBit(pages) // Changes the protection bit of the page to read-only

    return 0; 
}

int munprotect(void *addr, int len)
{
    //  Implement mprotect
    if(len<=0)  return -1;

    findallPages(void *addr, int len) // Function which will return all the pages that intersect the specified range

    changeBit(pages) // Changes the protection bit of the page to writable
    
    return 0;
}

```

## Test-Case
- For writing testcase make a seperate file say `endsem_` whose pseudo code and idea is written in the file `endsem_`. Also minor-tweaks in Make-file for compliling `endsem_.c`